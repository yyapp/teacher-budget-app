"""Supabase Storage 헬퍼. 영수증 파일 업로드/다운로드를 담당한다."""

import os
import uuid
from typing import Any, Dict, Optional

from .db import client

# Storage 버킷 이름. Supabase 콘솔에서 미리 만들어두어야 한다.
BUCKET_NAME = "receipts"


def _ensure_bucket() -> None:
    """ 버킷이 존재하는지 확인하고 없으면 생성을 시도한다.
    운영 시에는 Supabase 콘솔에서 직접 생성하는 것을 권장한다."""
    svc = client()
    try:
        svc.storage.get_bucket(BUCKET_NAME)
    except Exception:
        try:
            svc.storage.create_bucket(BUCKET_NAME, {"public": False})
        except Exception:
            # 이미 있거나 권한 문제가 있으면 조용히 넘어간다.
            pass


def upload_receipt(file_bytes: bytes, original_filename: str, content_type: str) -> Optional[str]:
    """영수증 파일을 Storage에 업로드하고 공개 URL을 반환한다.
    저장 경로: receipts/{uuid_접두어}/{원본파일명}"""
    _ensure_bucket()
    svc = client()
    file_id = uuid.uuid4().hex[:12]
    path = f"raw/{file_id}_{original_filename}"
    try:
        svc.storage.from_(BUCKET_NAME).upload(
            path,
            file_bytes,
            file_options={"contentType": content_type, "upsert": False},
        )
        # URL 얻기 (비공개 버킷이므로 서명 URL 생성)
        try:
            url = svc.storage.from_(BUCKET_NAME).create_signed_url(path, 3600)
            return url.get("signedUrl") if isinstance(url, dict) else str(url)
        except Exception:
            # 서명 URL 생성 실패 시 다운로드 경로 반환
            return f"/storage/{BUCKET_NAME}/{path}"
    except Exception:
        return None


def delete_receipt(file_path: str) -> bool:
    """Storage에서 파일을 삭제한다."""
    _ensure_bucket()
    svc = client()
    try:
        svc.storage.from_(BUCKET_NAME).remove([file_path])
        return True
    except Exception:
        return False


def list_receipts() -> list:
    """Storage 버킷의 파일 목록을 반환한다."""
    _ensure_bucket()
    svc = client()
    try:
        data = svc.storage.from_(BUCKET_NAME).list()
        return data if isinstance(data, list) else []
    except Exception:
        return []
