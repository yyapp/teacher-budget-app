"""모든 Flask 라우트. 비즈니스 로직은 services.py에 위임."""

import json
import os
import uuid
from functools import wraps
from typing import Any, Callable, Optional

from flask import Blueprint, Response, abort, flash, redirect, render_template, request, session, url_for
from werkzeug.utils import secure_filename

from . import services
from . storage import upload_receipt as storage_upload
from . forms import is_valid_amount, is_valid_quantity, safe_float, safe_int, non_empty_str

blueprint = Blueprint("app", __name__, template_folder="templates")

# --------------
# 인증
# --------------

def check_access(fn: Callable) -> Callable:
    """간단 비밀번호 인증. ACCESS_PASSWORD가 없으면 인증 없이 통과."""
    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        password = os.environ.get("ACCESS_PASSWORD", "")
        if not password:
            return fn(*args, **kwargs)
        if session.get("authenticated"):
            return fn(*args, **kwargs)
        if request.method == "POST" and request.form.get("password") == password:
            session["authenticated"] = True
            return fn(*args, **kwargs)
        return render_template("login.html", next=request.path)
    return wrapper


def logout() -> Response:
    session.pop("authenticated", None)
    return redirect(url_for("app.index"))


# --------------
# 헬퍼
# --------------

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "pdf", "heic", "heif"}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def _parse_cart_items(form_items: Any) -> list:
    """장바구니 폼에서 품목 목록을 파싱."""
    items = []
    if form_items:
        # form_items가 JSON 문자열이면 디코딩
        if isinstance(form_items, str):
            import json
            try:
                form_items = json.loads(form_items)
            except Exception:
                return []
        if isinstance(form_items, list):
            for idx, item in enumerate(form_items):
                desc = non_empty_str(item.get("description") if isinstance(item, dict) else item)
                qty = safe_int(item.get("quantity") if isinstance(item, dict) else 1)
                price = safe_float(item.get("price") if isinstance(item, dict) else 0)
                if desc:
                    items.append({
                        "description": desc,
                        "quantity": qty if qty >= 1 else 1,
                        "unit_price": price,
                        "amount": price * qty,
                    })
    return items


# --------------
# 라우트
# --------------

@blueprint.route("/")
@check_access
def index() -> str:
    """홈/대시보드."""
    budgets = services.list_budgets()
    recent_tx = services.list_transactions(limit=10)
    return render_template("index.html", budgets=budgets, recent_transactions=recent_tx)


@blueprint.route("/budgets")
@check_access
def budgets() -> str:
    """예산 목록 페이지."""
    budgets = services.list_budgets()
    return render_template("budgets.html", budgets=budgets)


@blueprint.route("/budgets/new", methods=["GET", "POST"])
@check_access
def budget_new() -> Any:
    if request.method == "POST":
        name = non_empty_str(request.form.get("name"))
        amount = safe_float(request.form.get("amount"))
        category = non_empty_str(request.form.get("category"))
        if not name:
            flash("예산 이름을 입력해 주세요.", "error")
            return redirect(url_for("app.budget_new"))
        if not is_valid_amount(amount):
            flash("예산 금액은 0 이상의 숫자를 입력해 주세요.", "error")
            return redirect(url_for("app.budget_new"))
        svc = services.create_budget(name, amount, category)
        if svc:
            flash("예산이 등록되었습니다.", "success")
            return redirect(url_for("app.budgets"))
        flash("예산 등록에 실패했습니다.", "error")
    return render_template("budget_form.html", budget=None, action="등록")


@blueprint.route("/budgets/<budget_id>/edit", methods=["GET", "POST"])
@check_access
def budget_edit(budget_id: str) -> Any:
    budget = services.get_budget(budget_id)
    if not budget:
        abort(404)
    if request.method == "POST":
        name = non_empty_str(request.form.get("name", budget["name"]))
        amount = safe_float(request.form.get("amount", budget["amount"]))
        category = non_empty_str(request.form.get("category", budget.get("category", "")))
        if not name:
            flash("예산 이름을 입력해 주세요.", "error")
            return redirect(url_for("app.budget_edit", budget_id=budget_id))
        if not is_valid_amount(amount):
            flash("예산 금액은 0 이상의 숫자를 입력해 주세요.", "error")
            return redirect(url_for("app.budget_edit", budget_id=budget_id))
        ok = services.update_budget(budget_id, name, amount, category)
        if ok:
            flash("예산이 수정되었습니다.", "success")
            return redirect(url_for("app.budgets"))
        flash("수정에 실패했습니다.", "error")
    return render_template("budget_form.html", budget=budget, action="수정")


@blueprint.route("/budgets/<budget_id>/delete", methods=["POST"])
@check_access
def budget_delete(budget_id: str) -> Response:
    ok = services.delete_budget(budget_id)
    if ok:
        flash("예산이 삭제되었습니다.", "success")
    else:
        flash("삭제 실패했습니다.", "error")
    return redirect(url_for("app.budgets"))


@blueprint.route("/upload", methods=["GET", "POST"])
@check_access
def upload() -> Any:
    """영수증 업로드 페이지."""
    budgets = services.list_budgets()
    if request.method == "POST":
        budget_id = non_empty_str(request.form.get("budget_id"))
        description = non_empty_str(request.form.get("description"))
        amount = safe_float(request.form.get("amount"))
        category = non_empty_str(request.form.get("category"))
        quantity = safe_int(request.form.get("quantity", 1))
        unit_price = safe_float(request.form.get("unit_price"))

        if not budget_id:
            flash("예산을 선택해 주세요.", "error")
            return redirect(url_for("app.upload"))
        if not description:
            flash("설명을 입력해 주세요.", "error")
            return redirect(url_for("app.upload"))
        if not is_valid_amount(amount):
            flash("금액은 0 이상의 숫자를 입력해 주세요.", "error")
            return redirect(url_for("app.upload"))

        receipt_path = None
        receipt_filename = None
        file = request.files.get("receipt_file")
        if file and file.filename:
            if not allowed_file(file.filename):
                flash("지원하지 않는 파일 형식입니다. (png, jpg, jpeg, pdf)", "error")
                return redirect(url_for("app.upload"))
            file.seek(0, os.SEEK_END)
            size = file.tell()
            file.seek(0)
            if size > MAX_FILE_SIZE:
                flash("파일 크기가 너무 큽니다. (최대 10MB)", "error")
                return redirect(url_for("app.upload"))
            file_bytes = file.read()
            ext = file.filename.rsplit(".", 1)[1].lower() if "." in file.filename else "bin"
            filename = secure_filename(file.filename) or f"receipt.{ext}"
            receipt_path = storage_upload(file_bytes, filename, f"image/{ext}" if ext in ("png","jpg","jpeg","heic","heif") else "application/pdf")
            receipt_filename = filename
            if not receipt_path:
                flash("파일 저장에 실패했습니다.", "error")
                return redirect(url_for("app.upload"))

        tx = services.create_transaction(
            budget_id=budget_id,
            description=description,
            amount=amount,
            category=category,
            quantity=quantity,
            unit_price=unit_price if unit_price else None,
            receipt_path=receipt_path,
            receipt_filename=receipt_filename,
        )
        if tx:
            flash("거래가 등록되었습니다.", "success")
            return redirect(url_for("app.ledger"))
        flash("거래 등록에 실패했습니다.", "error")
    return render_template("upload.html", budgets=budgets)


@blueprint.route("/ledger")
@check_access
def ledger() -> str:
    """거래 장부 페이지."""
    budget_id = request.args.get("budget_id", "")
    status = request.args.get("status", "")
    budgets = services.list_budgets()
    transactions = services.list_transactions(
        budget_id=budget_id if budget_id else None,
        status=status if status else None,
    )
    return render_template("ledger.html", transactions=transactions, budgets=budgets, selected_budget=budget_id, selected_status=status)


@blueprint.route("/transactions/<tx_id>")
@check_access
def transaction_detail(tx_id: str) -> str:
    """거래 상세 페이지."""
    tx = services.get_transaction(tx_id)
    if not tx:
        abort(404)
    return render_template("transaction_detail.html", transaction=tx)


@blueprint.route("/transactions/<tx_id>/confirm", methods=["POST"])
@check_access
def transaction_confirm(tx_id: str) -> Response:
    ok = services.confirm_transaction(tx_id)
    if ok:
        flash("거래가 확정되었습니다.", "success")
    else:
        flash("확정 실패했습니다. (이미 확정됐거나 취소 상태일 수 있음)", "error")
    return redirect(url_for("app.ledger"))


@blueprint.route("/transactions/<tx_id>/cancel", methods=["POST"])
@check_access
def transaction_cancel(tx_id: str) -> Response:
    ok = services.cancel_transaction(tx_id)
    if ok:
        flash("거래가 취소되었습니다.", "success")
    else:
        flash("취소 실패했습니다.", "error")
    return redirect(url_for("app.ledger"))


@blueprint.route("/transactions/<tx_id>/refund", methods=["GET", "POST"])
@check_access
def transaction_refund(tx_id: str) -> Any:
    """환불 처리 페이지."""
    tx = services.get_transaction(tx_id)
    if not tx:
        abort(404)
    if request.method == "POST":
        refund_amount = safe_float(request.form.get("refund_amount"))
        reason = non_empty_str(request.form.get("reason"))
        if not is_valid_amount(refund_amount):
            flash("환불 금액은 0 이상의 숫자를 입력해 주세요.", "error")
            return redirect(url_for("app.transaction_refund", tx_id=tx_id))
        ok = services.refund_transaction(tx_id, refund_amount, reason)
        if ok:
            flash("환불 처리되었습니다.", "success")
            return redirect(url_for("app.ledger"))
        flash("환불 실패했습니다.", "error")
    return render_template("refund.html", transaction=tx)


@blueprint.route("/transactions/<tx_id>/edit", methods=["GET", "POST"])
@check_access
def transaction_edit(tx_id: str) -> Any:
    tx = services.get_transaction(tx_id)
    if not tx:
        abort(404)
    if request.method == "POST":
        description = non_empty_str(request.form.get("description", tx["description"]))
        amount = safe_float(request.form.get("amount", tx["amount"]))
        category = non_empty_str(request.form.get("category", tx.get("category", "")))
        quantity = safe_int(request.form.get("quantity", tx.get("quantity", 1)))
        unit_price = safe_float(request.form.get("unit_price", tx.get("unit_price")))
        notes = non_empty_str(request.form.get("notes", tx.get("notes", "")))
        if not description:
            flash("설명을 입력해 주세요.", "error")
            return redirect(url_for("app.transaction_edit", tx_id=tx_id))
        if not is_valid_amount(amount):
            flash("금액은 0 이상의 숫자를 입력해 주세요.", "error")
            return redirect(url_for("app.transaction_edit", tx_id=tx_id))
        ok = services.update_transaction(
            tx_id,
            description=description,
            amount=amount,
            category=category,
            quantity=quantity,
            unit_price=unit_price if unit_price else None,
            notes=notes,
        )
        if ok:
            flash("거래가 수정되었습니다.", "success")
            return redirect(url_for("app.ledger"))
        flash("수정에 실패했습니다.", "error")
    return render_template("transaction_form.html", transaction=tx, action="수정")


@blueprint.route("/transactions/<tx_id>/delete", methods=["POST"])
@check_access
def transaction_delete(tx_id: str) -> Response:
    ok = services.delete_transaction(tx_id)
    if ok:
        flash("거래가 삭제되었습니다.", "success")
    else:
        flash("삭제할 수 없습니다. (확정·취소·환불된 거래는 삭제 불가)", "error")
    return redirect(url_for("app.ledger"))


@blueprint.route("/cart-review", methods=["GET", "POST"])
@check_access
def cart_review() -> Any:
    """장바구니 검토 페이지. 품목으로 품의 초안 생성."""
    budgets = services.list_budgets()
    if request.method == "POST":
        items_raw = request.form.getlist("items")
        items = _parse_cart_items(items_raw)
        notes = non_empty_str(request.form.get("notes"))
        if not items:
            flash("품목을 하나 이상 입력해 주세요.", "error")
            return redirect(url_for("app.cart_review"))
        proposal = services.create_cart_proposal(items, notes)
        if proposal:
            flash("품의 초안이 저장되었습니다.", "success")
            return redirect(url_for("app.cart_proposal_view", proposal_id=proposal["id"]))
        flash("저장 실패했습니다.", "error")
    return render_template("cart_review.html", budgets=budgets)


@blueprint.route("/cart-proposal")
@check_access
def cart_proposal_list() -> str:
    """Saved proposals list (from DB)."""
    proposals = services.list_cart_proposals()
    return render_template("cart_proposal_list.html", proposals=proposals)


@blueprint.route("/cart-proposal/<proposal_id>")
@check_access
def cart_proposal_view(proposal_id: str) -> str:
    """단일 품의 초안 보기 + 코드 복사."""
    proposal = services.get_cart_proposal(proposal_id)
    if not proposal:
        abort(404)
    return render_template("cart_proposal_view.html", proposal=proposal)


@blueprint.route("/manual-entry", methods=["GET", "POST"])
@check_access
def manual_entry() -> Any:
    """수기 입력 페이지 (영수증 없이 거래 등록)."""
    budgets = services.list_budgets()
    if request.method == "POST":
        budget_id = non_empty_str(request.form.get("budget_id"))
        description = non_empty_str(request.form.get("description"))
        amount = safe_float(request.form.get("amount"))
        category = non_empty_str(request.form.get("category"))
        quantity = safe_int(request.form.get("quantity", 1))
        unit_price = safe_float(request.form.get("unit_price"))
        notes = non_empty_str(request.form.get("notes"))

        if not budget_id:
            flash("예산을 선택해 주세요.", "error")
            return redirect(url_for("app.manual_entry"))
        if not description:
            flash("설명을 입력해 주세요.", "error")
            return redirect(url_for("app.manual_entry"))
        if not is_valid_amount(amount):
            flash("금액은 0 이상의 숫자를 입력해 주세요.", "error")
            return redirect(url_for("app.manual_entry"))

        tx = services.create_transaction(
            budget_id=budget_id,
            description=description,
            amount=amount,
            category=category,
            quantity=quantity,
            unit_price=unit_price if unit_price else None,
            notes=notes,
        )
        if tx:
            flash("거래가 등록되었습니다.", "success")
            return redirect(url_for("app.ledger"))
        flash("등록 실패했습니다.", "error")
    return render_template("manual_entry.html", budgets=budgets)


# --------------
# API (JSON)
# --------------

@blueprint.route("/api/balance")
@check_access
def api_balance() -> Response:
    """예산별 잔액 API."""
    budgets = services.list_budgets()
    result = []
    for b in budgets:
        balance = services.get_budget_balance(b["id"])
        result.append({
            "id": b["id"],
            "name": b["name"],
            "amount": float(b["amount"]),
            "balance": balance if balance is not None else 0,
        })
    return Response(response=json.dumps(result), status=200, mimetype="application/json")


@blueprint.route("/api/ledger")
@check_access
def api_ledger() -> Response:
    """거래 목록 API."""
    budget_id = request.args.get("budget_id", "")
    status = request.args.get("status", "")
    transactions = services.list_transactions(
        budget_id=budget_id if budget_id else None,
        status=status if status else None,
    )
    out = []
    for tx in transactions:
        out.append({
            "id": tx["id"],
            "budget_id": tx["budget_id"],
            "description": tx["description"],
            "amount": float(tx["amount"]),
            "category": tx.get("category", ""),
            "quantity": tx.get("quantity", 1),
            "unit_price": float(tx["unit_price"]) if tx.get("unit_price") is not None else None,
            "status": tx.get("status", ""),
            "receipt_path": tx.get("receipt_path"),
            "receipt_filename": tx.get("receipt_filename"),
            "notes": tx.get("notes", ""),
            "refund_amount": float(tx["refund_amount"]) if tx.get("refund_amount") is not None else None,
            "refund_reason": tx.get("refund_reason", ""),
            "created_at": tx.get("created_at"),
            "updated_at": tx.get("updated_at"),
        })
    return Response(response=json.dumps(out), status=200, mimetype="application/json")


@blueprint.route("/logout")
def logout_route() -> Response:
    return logout()
